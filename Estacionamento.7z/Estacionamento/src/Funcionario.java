
public class Funcionario extends Pessoa {


     private int codfunc;
     private int codcliente;
     private String funcao;
     private String senha;	
    
   
    public Funcionario(String nome, String telefone, String documento, int codfunc, int codcliente,
			String funcao, String senha) {
		super(nome, telefone, documento);
		this.codfunc = codfunc;
		this.codcliente = codcliente;
		this.funcao = funcao;
		this.senha = senha;
	}

	public int getCodfunc() {
        return this.codfunc;
    }
    
    public void setCodfunc(int codfunc) {
        this.codfunc = codfunc;
    }
   

    public String getFuncao() {
        return this.funcao;
    }
    
    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    public String getSenha() {
        return this.senha;
    }
    
    public void setSenha(String senha) {
        this.senha = senha;
    }
   

    public int getcodcliente() {
        return codcliente;
    }

    public void setcodcliente(int codcliente) {
        this.codcliente = codcliente;
    }
  

}


