
public class Moto extends Veiculo {

	@Override
	 public void tamanho() {
		
		
		
		}
	
}
