
public class Mensalista extends Cliente {

	public Mensalista(String nome, String telefone, String documento, int codcliente, String tipopessoa,
			String tipoPlano) {
		super(nome, telefone, documento, codcliente, tipopessoa, tipoPlano);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public int totalpagar() {
		return 200;
	}

	
	
}
