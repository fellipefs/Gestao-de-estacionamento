
public class Preco   {



     private Double hora;
     private Double dia;
     private Double mes;
     private int fixo = 2;
	
	
 
    public Preco(Double hora, Double dia, Double mes) {
     
       this.hora = hora;
       this.dia = dia;
       this.mes = mes;     
    }
  
  

}


