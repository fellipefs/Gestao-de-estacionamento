
public class Estacionamento  {


     private Integer qtdtotalvagas = 15;



    public Integer getQtdtotalvagas() {
        return this.qtdtotalvagas;
    }
    
    public void setQtdtotalvagas(Integer qtdtotalvagas) {
        this.qtdtotalvagas = qtdtotalvagas;
    }

    


}

