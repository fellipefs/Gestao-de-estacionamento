

public class Cliente extends Pessoa {

	private int codcliente;
    private String tipopessoa;
    private String tipoPlano;
    private int horaSaida;
	private int horaEntrada;
	private int fixo = 2;

		public Cliente(String nome, String telefone, String documento, int codcliente, String tipopessoa,
			String tipoPlano) {
		super(nome, telefone, documento);
		this.codcliente = codcliente;
		this.tipopessoa = tipopessoa;
		this.tipoPlano = tipoPlano;
	}

		public int getCodCliente() {
	        return this.codcliente;
	    }
	    
	    public void setCodCliente(int codcliente) {
	        this.codcliente = codcliente;
	    }
	 
	    public String getNome() {
	        return this.getNome();
	    }
	    

	    public String getTipopessoa() {
	        return this.tipopessoa;
	    }
	    
	    public void setTipopessoa(String tipopessoa) {
	        this.tipopessoa = tipopessoa;
	    }
	    public String getTipoPlano() {
	        return this.tipoPlano;
	    }
	    
	    public void setTipoPlano(String tipoPlano) {
	        this.tipoPlano = tipoPlano;
	    }
	    

	    public void pagamento (double horaEntrada, double horaSaida) {
			this.horaEntrada = 10;
			this.horaSaida = 15;
		
		}
		
		public int totalpagar( ) {
			return horaSaida - horaEntrada * fixo;
		
		}
	   
	}


