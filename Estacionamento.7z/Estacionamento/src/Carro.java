
public class Carro extends Veiculo {
	
	
	@Override
	 public void tamanho() {
		
		
		
		}

}
