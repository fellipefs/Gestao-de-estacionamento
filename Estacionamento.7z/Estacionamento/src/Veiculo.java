
public class Veiculo  {


     private int codveiculo;
     private int codcliente;
     private String modelo;
     private int ano;
     private String marca;
     private String cor;
     private String placa;
     private int vaga;
     private int qtdveiculos;

    public Veiculo() {
    }
	
    public Veiculo(int codveiculo, Cliente cliente) {
        this.codveiculo = codveiculo;

    }
    
    public Veiculo(int codveiculo, String modelo, String marca, String cor, String placa) {
       this.codveiculo = codveiculo;
       this.modelo = modelo;
       this.marca = marca;
       this.cor = cor;
       this.placa = placa;
   
    }
   
    public int getcodveiculo() {
        return this.codveiculo;
    }
    
    public void setcodveiculo(int codveiculo) {
        this.codveiculo = codveiculo;
    }

    public String getModelo() {
        return this.modelo;
    }
    
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public String getMarca() {
        return this.marca;
    }
    
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public String getCor() {
        return this.cor;
    }
    
    public void setCor(String cor) {
        this.cor = cor;
    }
    public String getPlaca() {
        return this.placa;
    }
    
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getcodcliente() {
        return codcliente;
    }

    public void setcodcliente(int codcliente) {
        this.codcliente = codcliente;
    }

    public int getVaga() {
        return vaga;
    }

    public void setVaga(int vaga) {
        this.vaga = vaga;
    }

    public int getQtdveiculos() {
        return qtdveiculos;
    }

    public void setQtdveiculos(int qtdveiculos) {
        this.qtdveiculos = qtdveiculos;
    }

    public void tamanho() {
    
	}

}



